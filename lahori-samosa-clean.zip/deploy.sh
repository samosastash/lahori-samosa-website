#!/bin/bash

# Lahori Samosa - Build and Deploy Script

echo "🚀 Building Lahori Samosa Website..."

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Build the project
echo "🔨 Building project..."
npm run build

# Check if build was successful
if [ $? -eq 0 ]; then
    echo "✅ Build successful!"
    echo "📁 Build files created in 'build' directory"
    echo ""
    echo "🌐 Ready for deployment to Vercel!"
    echo "📋 Next steps:"
    echo "   1. Push code to GitHub"
    echo "   2. Connect repository to Vercel"
    echo "   3. Add environment variables"
    echo "   4. Deploy!"
else
    echo "❌ Build failed!"
    echo "Please check the error messages above."
fi

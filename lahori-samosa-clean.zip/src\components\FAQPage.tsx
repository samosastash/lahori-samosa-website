import React from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, ChevronUp, HelpCircle, Phone, Mail, Clock, MapPin } from 'lucide-react';

export function FAQPage() {
  const [openItems, setOpenItems] = React.useState<number[]>([]);

  const toggleItem = (index: number) => {
    setOpenItems(prev => 
      prev.includes(index) 
        ? prev.filter(i => i !== index)
        : [...prev, index]
    );
  };

  const faqData = [
    {
      question: "What are your delivery hours?",
      answer: "We deliver from 11:00 AM to 11:00 PM, 7 days a week. Orders placed after 10:30 PM will be delivered the next day."
    },
    {
      question: "What is your delivery area?",
      answer: "We deliver within Lahore city limits. Free delivery is available for orders over Rs. 1000. Delivery fee is Rs. 100 for orders below Rs. 1000."
    },
    {
      question: "How long does delivery take?",
      answer: "Standard delivery time is 15-30 minutes for orders within Lahore city limits. Delivery time may vary during peak hours or bad weather conditions."
    },
    {
      question: "What payment methods do you accept?",
      answer: "We currently accept Cash on Delivery (COD) only. Payment is made when your order is delivered to your doorstep."
    },
    {
      question: "Can I cancel my order?",
      answer: "You can cancel your order by calling us at +92 324 4060113 before we start preparing it. Once preparation begins, cancellation may not be possible."
    },
    {
      question: "Do you have vegetarian options?",
      answer: "Yes! We offer a variety of vegetarian samosas including Aloo Samosa, Cheese Samosa, and Vegetable Samosa. All vegetarian items are clearly marked on our menu."
    },
    {
      question: "Are your samosas halal?",
      answer: "Yes, all our samosas are prepared using halal ingredients and follow Islamic dietary guidelines. We maintain strict halal standards in our kitchen."
    },
    {
      question: "Can I place a bulk order?",
      answer: "Absolutely! For bulk orders (20+ samosas), please call us at +92 324 4060113 at least 2 hours in advance. We offer special pricing for bulk orders."
    },
    {
      question: "What if I'm not satisfied with my order?",
      answer: "Your satisfaction is our priority! If you're not happy with your order, please contact us immediately at +92 324 4060113. We'll do our best to resolve any issues."
    },
    {
      question: "Do you offer catering services?",
      answer: "Yes, we provide catering services for events, parties, and corporate functions. Please contact us at +92 324 4060113 for custom catering arrangements and pricing."
    }
  ];

  return (
    <div className="pt-20 min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <div className="flex items-center justify-center mb-6">
            <HelpCircle className="w-12 h-12 text-orange-600 mr-4" />
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900">
              Frequently Asked Questions
            </h1>
          </div>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Find answers to common questions about Lahori Samosa Shop's delivery, ordering, and services.
          </p>
        </motion.div>

        {/* FAQ Items */}
        <div className="space-y-4 mb-12">
          {faqData.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-xl shadow-lg overflow-hidden"
            >
              <button
                onClick={() => toggleItem(index)}
                className="w-full px-6 py-5 text-left flex items-center justify-between hover:bg-gray-50 transition-colors"
              >
                <h3 className="text-lg font-semibold text-gray-900 pr-4">
                  {item.question}
                </h3>
                {openItems.includes(index) ? (
                  <ChevronUp className="w-5 h-5 text-orange-600 flex-shrink-0" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-orange-600 flex-shrink-0" />
                )}
              </button>
              
              {openItems.includes(index) && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="px-6 pb-5"
                >
                  <div className="border-t border-gray-200 pt-4">
                    <p className="text-gray-700 leading-relaxed">
                      {item.answer}
                    </p>
                  </div>
                </motion.div>
              )}
            </motion.div>
          ))}
        </div>

        {/* Contact Information */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-gradient-to-br from-orange-50 to-yellow-50 rounded-2xl p-8 shadow-lg"
        >
          <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">
            Still Have Questions?
          </h2>
          <p className="text-gray-700 text-center mb-8">
            Can't find what you're looking for? Contact us directly and we'll be happy to help!
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Phone */}
            <div className="flex items-center space-x-4 p-4 bg-white rounded-lg shadow-sm">
              <div className="bg-orange-100 p-3 rounded-full">
                <Phone className="w-6 h-6 text-orange-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">Call Us</h3>
                <p className="text-gray-600">+92 324 4060113</p>
                <p className="text-sm text-gray-500">Available 11 AM - 11 PM</p>
              </div>
            </div>

            {/* Email */}
            <div className="flex items-center space-x-4 p-4 bg-white rounded-lg shadow-sm">
              <div className="bg-orange-100 p-3 rounded-full">
                <Mail className="w-6 h-6 text-orange-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">Email Us</h3>
                <p className="text-gray-600">info@lahorisamosa.com</p>
                <p className="text-sm text-gray-500">We'll respond within 24 hours</p>
              </div>
            </div>

            {/* Hours */}
            <div className="flex items-center space-x-4 p-4 bg-white rounded-lg shadow-sm">
              <div className="bg-orange-100 p-3 rounded-full">
                <Clock className="w-6 h-6 text-orange-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">Business Hours</h3>
                <p className="text-gray-600">11:00 AM - 11:00 PM</p>
                <p className="text-sm text-gray-500">7 days a week</p>
              </div>
            </div>

            {/* Location */}
            <div className="flex items-center space-x-4 p-4 bg-white rounded-lg shadow-sm">
              <div className="bg-orange-100 p-3 rounded-full">
                <MapPin className="w-6 h-6 text-orange-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">Delivery Area</h3>
                <p className="text-gray-600">Lahore City</p>
                <p className="text-sm text-gray-500">Free delivery over Rs. 1000</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

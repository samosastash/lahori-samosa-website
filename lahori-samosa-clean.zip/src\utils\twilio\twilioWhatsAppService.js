// Twilio WhatsApp Service for Lahori Samosa
// This service sends actual WhatsApp messages using Twilio WhatsApp API

import twilio from 'twilio';

export class TwilioWhatsAppService {
  constructor() {
    this.client = null;
    this.config = {
      accountSid: process.env.TWILIO_ACCOUNT_SID,
      authToken: process.env.TWILIO_AUTH_TOKEN,
      whatsappNumber: '+14155238886', // Twilio WhatsApp Sandbox number
      otpLength: 6,
      otpExpiryMinutes: 5,
      whatsappOnly: true // Force WhatsApp only, no SMS fallback
    };
    this.initializeClient();
    this.otpStorage = new Map(); // Store OTPs in memory
  }

  // Initialize Twilio client
  initializeClient() {
    try {
      this.client = twilio(this.config.accountSid, this.config.authToken);
      console.log('✅ Twilio WhatsApp client initialized successfully');
    } catch (error) {
      console.error('❌ Twilio WhatsApp client initialization failed:', error);
    }
  }

  // Format phone number for WhatsApp
  formatPhoneNumber(phone) {
    let cleaned = phone.replace(/\D/g, '');
    if (!cleaned.startsWith('+')) {
      cleaned = '+' + cleaned;
    }
    return cleaned;
  }

  // Generate random OTP
  generateOTP() {
    return Math.floor(100000 + Math.random() * 900000).toString();
  }

  // Send WhatsApp OTP (with SMS fallback)
  async sendOTP(phone, ip) {
    try {
      if (!this.client) {
        throw new Error('Twilio client not initialized');
      }

      // Generate OTP
      const otp = this.generateOTP();
      const otpId = `twilio_whatsapp_${Date.now()}_${Math.random().toString(36).substring(2)}`;
      const expires = Date.now() + (this.config.otpExpiryMinutes * 60 * 1000);

      // Store OTP
      this.otpStorage.set(otpId, {
        otp,
        phone: this.formatPhoneNumber(phone),
        expires,
        attempts: 0
      });

      // Create message
      const message = `🍴 Lahori Samosa - Order Verification

Your verification code is: ${otp}

⏰ Valid for 5 minutes
🔒 Do not share this code with anyone

Thank you for choosing Lahori Samosa! 🥟`;

      // Format phone number for WhatsApp Sandbox
      const formattedPhone = `whatsapp:${this.formatPhoneNumber(phone)}`;

      // Use WhatsApp Sandbox only (no SMS fallback to avoid daily limits)
      let result;
      let messageType = 'WhatsApp';
      
      try {
        // Use WhatsApp Sandbox only
        result = await this.client.messages.create({
          body: message,
          from: `whatsapp:${this.config.whatsappNumber}`, // WhatsApp Sandbox number
          to: formattedPhone
        });
        console.log(`✅ WhatsApp OTP sent successfully to ${phone}`);
      } catch (whatsappError) {
        // Don't fallback to SMS to avoid daily limits
        console.log('❌ WhatsApp Sandbox error:', whatsappError.message);
        throw whatsappError;
      }

      console.log(`📱 Message ID: ${result.sid}`);
      console.log(`🔐 OTP Code: ${otp}`);

      return {
        success: true,
        otpId,
        message: `${messageType} verification code sent successfully!`,
        messageId: result.sid,
        messageType: messageType,
        expiresIn: this.config.otpExpiryMinutes * 60,
        debugOTP: otp // For testing
      };

    } catch (error) {
      console.error('❌ Twilio send error:', error);
      
      // Handle specific Twilio errors
      if (error.code === 21608) {
        return {
          success: false,
          message: 'Phone number not verified. Please verify your number in Twilio console or upgrade your account.'
        };
      } else if (error.code === 21211) {
        return {
          success: false,
          message: 'Invalid phone number format. Please check the number and try again.'
        };
      } else if (error.code === 63007) {
        return {
          success: false,
          message: 'WhatsApp Sandbox not connected. Please connect your WhatsApp to the sandbox first.'
        };
      } else if (error.code === 63038) {
        return {
          success: false,
          message: 'WhatsApp Sandbox daily limit reached. Please try again tomorrow or connect your WhatsApp to the sandbox properly.'
        };
      } else {
        return {
          success: false,
          message: 'Failed to send WhatsApp verification. Please ensure your WhatsApp is connected to the sandbox.'
        };
      }
    }
  }

  // Verify OTP
  async verifyOTP(otpId, otp) {
    const otpData = this.otpStorage.get(otpId);

    if (!otpData) {
      return { success: false, message: 'Invalid or expired OTP ID.' };
    }

    // Check if OTP is expired
    if (Date.now() > otpData.expires) {
      this.otpStorage.delete(otpId); // Remove expired OTP
      return { success: false, message: 'OTP expired. Please request a new one.' };
    }

    // Check if OTP matches
    if (otpData.otp === otp) {
      this.otpStorage.delete(otpId); // OTP successfully verified, remove it
      return { success: true, message: 'Phone number verified successfully!' };
    } else {
      return { success: false, message: 'Incorrect OTP. Please try again.' };
    }
  }

  // Send WhatsApp order confirmation
  async sendOrderConfirmation(phone, message, orderId) {
    try {
      if (!this.client) {
        throw new Error('Twilio client not initialized');
      }

      // Format phone number
      const formattedPhone = `whatsapp:${this.formatPhoneNumber(phone)}`;

      // Use WhatsApp Sandbox only (no SMS fallback)
      let result;
      let messageType = 'WhatsApp';

      try {
        // Use WhatsApp Sandbox only
        result = await this.client.messages.create({
          body: message,
          from: `whatsapp:${this.config.whatsappNumber}`, // WhatsApp Sandbox number
          to: formattedPhone
        });
        console.log(`✅ WhatsApp order confirmation sent successfully to ${phone}`);
      } catch (whatsappError) {
        // Don't fallback to SMS to avoid daily limits
        console.log('❌ WhatsApp Sandbox error:', whatsappError.message);
        throw whatsappError;
      }

      console.log(`📱 Order Confirmation Message ID: ${result.sid}`);
      console.log(`📋 Order ID: ${orderId}`);

      return {
        success: true,
        message: `${messageType} order confirmation sent successfully!`,
        messageId: result.sid,
        messageType: messageType,
        orderId: orderId
      };

    } catch (error) {
      console.error('❌ Twilio order confirmation error:', error);

      // Handle specific Twilio errors
      if (error.code === 21608) {
        return {
          success: false,
          message: 'Phone number not verified. Order confirmation could not be sent.'
        };
      } else if (error.code === 21211) {
        return {
          success: false,
          message: 'Invalid phone number format. Order confirmation could not be sent.'
        };
      } else if (error.code === 63007) {
        return {
          success: false,
          message: 'WhatsApp is not enabled for this number. Order confirmation could not be sent.'
        };
      } else {
        return {
          success: false,
          message: 'Failed to send WhatsApp order confirmation. Please ensure WhatsApp Sandbox is properly connected.'
        };
      }
    }
  }

  // Send WhatsApp notification to site owner
  async sendOwnerNotification(orderData) {
    try {
      if (!this.client) {
        throw new Error('Twilio client not initialized');
      }

      // Site owner's WhatsApp number
      const ownerNumber = '+923244060113';
      const formattedOwnerNumber = `whatsapp:${this.formatPhoneNumber(ownerNumber)}`;

      // Create owner notification message
      const ownerMessage = `🎉 *New Order Received!* 🎉

A new order has been placed on your website.

*Order ID:* ${orderData.orderId}
*Customer Name:* ${orderData.customerName}
*Customer Phone:* ${orderData.customerPhone}
*Total Amount:* Rs.${orderData.totalAmount}

*Order Items:*
${orderData.items.map(item => `• ${item.name} (Qty: ${item.quantity}) - Rs.${item.price * item.quantity}`).join('\n')}

*Delivery Address:*
${orderData.deliveryAddress}

*Payment Method:* ${orderData.paymentMethod}

Please check your email or dashboard for full details.

*Time:* ${new Date().toLocaleString('en-PK', { timeZone: 'Asia/Karachi' })}`;

      // Use WhatsApp Sandbox only (no SMS fallback)
      let result;
      let messageType = 'WhatsApp';

      try {
        // Use WhatsApp Sandbox only
        result = await this.client.messages.create({
          body: ownerMessage,
          from: `whatsapp:${this.config.whatsappNumber}`, // WhatsApp Sandbox number
          to: formattedOwnerNumber
        });
        console.log(`✅ WhatsApp owner notification sent successfully to ${ownerNumber}`);
      } catch (whatsappError) {
        // Don't fallback to SMS to avoid daily limits
        console.log('❌ WhatsApp Sandbox error:', whatsappError.message);
        throw whatsappError;
      }

      console.log(`📱 Owner Notification Message ID: ${result.sid}`);
      console.log(`📋 Order ID: ${orderData.orderId}`);

      return {
        success: true,
        message: `${messageType} owner notification sent successfully!`,
        messageId: result.sid,
        messageType: messageType,
        orderId: orderData.orderId
      };

    } catch (error) {
      console.error('❌ Twilio owner notification error:', error);

      // Handle specific Twilio errors
      if (error.code === 21608) {
        return {
          success: false,
          message: 'Owner phone number not verified. Notification could not be sent.'
        };
      } else if (error.code === 21211) {
        return {
          success: false,
          message: 'Invalid owner phone number format. Notification could not be sent.'
        };
      } else if (error.code === 63007) {
        return {
          success: false,
          message: 'WhatsApp is not enabled for owner number. Notification could not be sent.'
        };
      } else {
        return {
          success: false,
          message: 'Failed to send WhatsApp owner notification. Please ensure WhatsApp Sandbox is properly connected.'
        };
      }
    }
  }
}

// Export singleton instance
export const twilioWhatsAppService = new TwilioWhatsAppService();
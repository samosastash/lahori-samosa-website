import express from 'express';
import { twilioWhatsAppService } from '../utils/twilio/twilioWhatsAppService.js';

const router = express.Router();

console.log('🚀 OTP Routes module loaded successfully');

// Send OTP endpoint
router.post('/send-otp', async (req, res) => {
  console.log('📱 Send OTP endpoint called');
  try {
    const { phone, ip } = req.body;

    if (!phone) {
      return res.status(400).json({
        success: false,
        message: 'Phone number is required.'
      });
    }

    const result = await twilioWhatsAppService.sendOTP(phone, ip || 'unknown');
    
    res.json(result);
  } catch (error) {
    console.error('Send OTP error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error.'
    });
  }
});

// Verify OTP endpoint
router.post('/verify-otp', async (req, res) => {
  try {
    const { otpId, otp } = req.body;

    if (!otpId || !otp) {
      return res.status(400).json({
        success: false,
        message: 'OTP ID and code are required.'
      });
    }

    const result = await twilioWhatsAppService.verifyOTP(otpId, otp);
    
    res.json(result);
  } catch (error) {
    console.error('Verify OTP error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error.'
    });
  }
});

// Clear rate limits endpoint (for testing)
router.post('/clear-rate-limits', async (req, res) => {
  try {
    // Twilio WhatsApp service doesn't need rate limit clearing
    res.json({
      success: true,
      message: 'Rate limits cleared successfully (Twilio WhatsApp service)'
    });
  } catch (error) {
    console.error('Clear rate limits error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to clear rate limits'
    });
  }
});

       // Send WhatsApp order confirmation endpoint
       router.post('/send-whatsapp-confirmation', async (req, res) => {
         try {
           const { phone, message, orderId } = req.body;

           if (!phone || !message) {
             return res.status(400).json({
               success: false,
               message: 'Phone number and message are required.'
             });
           }

           const result = await twilioWhatsAppService.sendOrderConfirmation(phone, message, orderId);

           res.json(result);
         } catch (error) {
           console.error('Send WhatsApp confirmation error:', error);
           res.status(500).json({
             success: false,
             message: 'Internal server error.'
           });
         }
       });

       // Send WhatsApp notification to site owner endpoint
       router.post('/send-owner-notification', async (req, res) => {
         try {
           const { orderData } = req.body;

           if (!orderData || !orderData.orderId) {
             return res.status(400).json({
               success: false,
               message: 'Order data is required.'
             });
           }

           const result = await twilioWhatsAppService.sendOwnerNotification(orderData);

           res.json(result);
         } catch (error) {
           console.error('Send owner notification error:', error);
           res.status(500).json({
             success: false,
             message: 'Internal server error.'
           });
         }
       });

export default router;

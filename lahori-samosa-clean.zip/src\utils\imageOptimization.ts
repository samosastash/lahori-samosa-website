// Image optimization utilities
export const imageOptimization = {
  // Generate responsive image sizes
  generateSizes: (baseWidth: number) => {
    return [
      { width: baseWidth * 0.5, suffix: '_sm' },
      { width: baseWidth, suffix: '_md' },
      { width: baseWidth * 1.5, suffix: '_lg' },
      { width: baseWidth * 2, suffix: '_xl' }
    ];
  },

  // Get optimal image format based on browser support
  getOptimalFormat: () => {
    if (typeof window === 'undefined') return 'jpg';
    
    const canvas = document.createElement('canvas');
    const webpSupported = canvas.toDataURL('image/webp').indexOf('data:image/webp') === 0;
    const avifSupported = canvas.toDataURL('image/avif').indexOf('data:image/avif') === 0;
    
    if (avifSupported) return 'avif';
    if (webpSupported) return 'webp';
    return 'jpg';
  },

  // Generate srcset for responsive images
  generateSrcSet: (baseSrc: string, sizes: number[]) => {
    return sizes
      .map(size => `${baseSrc}?w=${size}&q=80 ${size}w`)
      .join(', ');
  },

  // Preload critical images
  preloadImages: (imageUrls: string[]) => {
    imageUrls.forEach(url => {
      const link = document.createElement('link');
      link.rel = 'preload';
      link.as = 'image';
      link.href = url;
      document.head.appendChild(link);
    });
  },

  // Lazy load images with intersection observer
  createLazyLoader: (callback: (entries: IntersectionObserverEntry[]) => void) => {
    return new IntersectionObserver(callback, {
      rootMargin: '50px',
      threshold: 0.1
    });
  }
};

// Image compression utilities
export const imageCompression = {
  // Compress image data URL
  compressImage: async (file: File, quality: number = 0.8): Promise<string> => {
    return new Promise((resolve) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();
      
      img.onload = () => {
        canvas.width = img.width;
        canvas.height = img.height;
        ctx?.drawImage(img, 0, 0);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      
      img.src = URL.createObjectURL(file);
    });
  },

  // Resize image
  resizeImage: async (file: File, maxWidth: number, maxHeight: number): Promise<string> => {
    return new Promise((resolve) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();
      
      img.onload = () => {
        let { width, height } = img;
        
        // Calculate new dimensions
        if (width > height) {
          if (width > maxWidth) {
            height = (height * maxWidth) / width;
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = (width * maxHeight) / height;
            height = maxHeight;
          }
        }
        
        canvas.width = width;
        canvas.height = height;
        ctx?.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', 0.8));
      };
      
      img.src = URL.createObjectURL(file);
    });
  }
};

// Performance monitoring
export const imagePerformance = {
  // Track image load times
  trackImageLoad: (src: string) => {
    const startTime = performance.now();
    const img = new Image();
    
    img.onload = () => {
      const loadTime = performance.now() - startTime;
      console.log(`Image ${src} loaded in ${loadTime.toFixed(2)}ms`);
    };
    
    img.src = src;
  },

  // Monitor Core Web Vitals for images
  monitorLCP: () => {
    if (typeof window === 'undefined') return;
    
    const observer = new PerformanceObserver((list) => {
      const entries = list.getEntries();
      const lastEntry = entries[entries.length - 1];
      
      if (lastEntry && lastEntry.element) {
        const img = lastEntry.element as HTMLImageElement;
        console.log(`LCP image: ${img.src}, load time: ${lastEntry.startTime}ms`);
      }
    });
    
    observer.observe({ entryTypes: ['largest-contentful-paint'] });
  }
};

import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { MessageCircle, Shield, CheckCircle, XCircle, Clock, ExternalLink, Smartphone } from 'lucide-react';

interface OTPVerificationProps {
  phone: string;
  onVerified: (phone: string) => void;
  onCancel: () => void;
}

export function OTPVerification({ phone, onVerified, onCancel }: OTPVerificationProps) {
  const [otp, setOtp] = useState('');
  const [otpId, setOtpId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [message, setMessage] = useState('');
  const [timeLeft, setTimeLeft] = useState(0);
  const [canResend, setCanResend] = useState(false);
  const [whatsappURL, setWhatsappURL] = useState<string | null>(null);

  // Send initial OTP
  useEffect(() => {
    sendOTP();
  }, []);

  // Timer for resend functionality
  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else {
      setCanResend(true);
    }
  }, [timeLeft]);

  const sendOTP = async () => {
    setLoading(true);
    setMessage('');
    
    try {
      const response = await fetch(`http://localhost:3001/api/send-otp?t=${Date.now()}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          phone,
          ip: 'localhost'
        }),
      });

      const data = await response.json();
      
      if (data.success) {
        setOtpId(data.otpId);
        setMessage(data.message || 'WhatsApp verification code sent successfully!');
        setTimeLeft(data.expiresIn || 300);
        setCanResend(false);
        
        // For testing - log the OTP to console
        if (data.debugOTP) {
          console.log(`🔐 Your OTP Code: ${data.debugOTP}`);
          console.log(`📱 Message ID: ${data.messageId}`);
          console.log(`💡 Note: If you don't receive SMS, try using +923244060113 for testing`);
        }
      } else {
        setMessage(data.message || 'Failed to send WhatsApp verification. Please try again.');
      }
    } catch (error) {
      setMessage('Failed to send verification code. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const verifyOTP = async () => {
    if (!otpId || otp.length !== 6) {
      setMessage('Please enter a valid 6-digit code.');
      return;
    }

    setVerifying(true);
    setMessage('');

    try {
      const response = await fetch('http://localhost:3001/api/verify-otp', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          otpId,
          otp
        }),
      });

      const data = await response.json();
      
      if (data.success) {
        setMessage(data.message);
        setTimeout(() => onVerified(phone), 1000);
      } else {
        setMessage(data.message);
      }
    } catch (error) {
      setMessage('Verification failed. Please try again.');
    } finally {
      setVerifying(false);
    }
  };

  const getClientIP = async (): Promise<string> => {
    try {
      const response = await fetch('https://api.ipify.org?format=json');
      const data = await response.json();
      return data.ip;
    } catch {
      return 'unknown';
    }
  };

  const handleOtpChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, '').slice(0, 6);
    setOtp(value);
    
    // Auto-submit when 6 digits are entered
    if (value.length === 6) {
      verifyOTP();
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
    >
      <motion.div
        initial={{ y: 20 }}
        animate={{ y: 0 }}
        className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6"
      >
        {/* Header */}
        <div className="text-center mb-6">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4"
          >
                  <MessageCircle className="w-8 h-8 text-emerald-600" />
          </motion.div>
          
          <h2 className="text-2xl font-semibold text-gray-900 mb-2">
            Verify Your Phone
          </h2>
          <p className="text-gray-600">
            We've sent a verification code via WhatsApp
          </p>
          <p className="text-emerald-600 font-medium">
            {phone}
          </p>
        </div>

        {/* OTP Input */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Enter Verification Code
          </label>
          <input
            type="text"
            value={otp}
            onChange={handleOtpChange}
            placeholder="000000"
            className="w-full px-4 py-3 text-center text-2xl font-mono border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent tracking-widest"
            maxLength={6}
            disabled={verifying}
          />
        </div>

        {/* Message */}
        {message && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`mb-4 p-3 rounded-lg flex items-center ${
              message.includes('success') || message.includes('verified')
                ? 'bg-green-50 text-green-700'
                : message.includes('expired') || message.includes('incorrect')
                ? 'bg-red-50 text-red-700'
                : 'bg-blue-50 text-blue-700'
            }`}
          >
            {message.includes('success') || message.includes('verified') ? (
              <CheckCircle className="w-5 h-5 mr-2" />
            ) : message.includes('expired') || message.includes('incorrect') ? (
              <XCircle className="w-5 h-5 mr-2" />
            ) : (
              <Clock className="w-5 h-5 mr-2" />
            )}
            <span className="text-sm">{message}</span>
          </motion.div>
        )}

        {/* Actions */}
        <div className="space-y-3">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={verifyOTP}
            disabled={verifying || otp.length !== 6}
            className="w-full py-3 bg-emerald-600 text-white rounded-lg font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
          >
            {verifying ? (
              <>
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                Verifying...
              </>
            ) : (
              <>
                <Shield className="w-5 h-5 mr-2" />
                Verify Phone Number
              </>
            )}
          </motion.button>

          <div className="flex space-x-3">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={sendOTP}
              disabled={loading || !canResend}
              className="flex-1 py-2 border border-gray-300 text-gray-700 rounded-lg font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Sending...' : `Resend Code ${timeLeft > 0 ? `(${timeLeft}s)` : ''}`}
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={onCancel}
              className="flex-1 py-2 border border-gray-300 text-gray-700 rounded-lg font-medium"
            >
              Cancel
            </motion.button>
          </div>
        </div>

        {/* Security Notice */}
        <div className="mt-6 p-3 bg-gray-50 rounded-lg">
          <p className="text-xs text-gray-600 text-center">
            <Shield className="w-4 h-4 inline mr-1" />
            Your phone number is verified securely and will not be shared with third parties.
          </p>
        </div>
      </motion.div>
    </motion.div>
  );
}

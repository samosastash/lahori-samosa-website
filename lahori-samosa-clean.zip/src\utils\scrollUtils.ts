import React from 'react';

// Scroll utility functions
export const scrollUtils = {
  // Scroll to top of page
  scrollToTop: (smooth: boolean = true) => {
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: smooth ? 'smooth' : 'instant'
    });
  },

  // Scroll to specific element
  scrollToElement: (elementId: string, offset: number = 0, smooth: boolean = true) => {
    const element = document.getElementById(elementId);
    if (element) {
      const elementPosition = element.offsetTop - offset;
      window.scrollTo({
        top: elementPosition,
        left: 0,
        behavior: smooth ? 'smooth' : 'instant'
      });
    }
  },

  // Scroll to specific position
  scrollToPosition: (top: number, left: number = 0, smooth: boolean = true) => {
    window.scrollTo({
      top,
      left,
      behavior: smooth ? 'smooth' : 'instant'
    });
  },

  // Check if element is in viewport
  isInViewport: (element: HTMLElement): boolean => {
    const rect = element.getBoundingClientRect();
    return (
      rect.top >= 0 &&
      rect.left >= 0 &&
      rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
      rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
  },

  // Get current scroll position
  getScrollPosition: () => {
    return {
      top: window.pageYOffset || document.documentElement.scrollTop,
      left: window.pageXOffset || document.documentElement.scrollLeft
    };
  },

  // Scroll to bottom of page
  scrollToBottom: (smooth: boolean = true) => {
    window.scrollTo({
      top: document.documentElement.scrollHeight,
      left: 0,
      behavior: smooth ? 'smooth' : 'instant'
    });
  }
};

// Hook for scroll position
export const useScrollPosition = () => {
  const [scrollPosition, setScrollPosition] = React.useState(scrollUtils.getScrollPosition());

  React.useEffect(() => {
    const handleScroll = () => {
      setScrollPosition(scrollUtils.getScrollPosition());
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return scrollPosition;
};

// Hook for scroll to top functionality
export const useScrollToTop = () => {
  const scrollToTop = React.useCallback((smooth: boolean = true) => {
    scrollUtils.scrollToTop(smooth);
  }, []);

  return scrollToTop;
};

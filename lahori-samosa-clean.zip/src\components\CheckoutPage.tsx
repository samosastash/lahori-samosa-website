import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CreditCard, MapPin, Phone, User, MessageCircle, Shield } from 'lucide-react';
import { useCart } from './CartContext';
import { supabase } from '../utils/supabase/client';
import { OTPVerification } from './OTPVerification';

export function CheckoutPage() {
  const { state, dispatch } = useCart();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [showOTPVerification, setShowOTPVerification] = useState(false);
  const [phoneVerified, setPhoneVerified] = useState(false);
  const [customerInfo, setCustomerInfo] = useState({
    name: '',
    phone: '',
    email: '',
    address: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setCustomerInfo({
      ...customerInfo,
      [e.target.name]: e.target.value
    });
  };

  const handlePhoneVerification = (verifiedPhone: string) => {
    setPhoneVerified(true);
    setShowOTPVerification(false);
    setCustomerInfo(prev => ({ ...prev, phone: verifiedPhone }));
  };

  const handleOTPCancel = () => {
    setShowOTPVerification(false);
  };

  const handleVerifyPhone = () => {
    if (!customerInfo.phone) {
      alert('Please enter your phone number first.');
      return;
    }
    setShowOTPVerification(true);
  };

  // Redirect to cart if no items - use useEffect to avoid render-time navigation
  useEffect(() => {
    if (state.items.length === 0) {
      navigate('/cart');
    }
  }, [state.items.length, navigate]);

  // Test Supabase connection on component mount
  useEffect(() => {
    const testConnection = async () => {
      try {
        console.log('Testing Supabase connection...');
        const { data, error } = await supabase
          .from('orders')
          .select('id')
          .limit(1);
        
        if (error) {
          console.warn('Supabase connection test failed:', error.message);
        } else {
          console.log('Supabase connection successful');
        }
      } catch (err) {
        console.warn('Supabase connection error:', err);
      }
    };
    
    testConnection();
  }, []);

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Check if phone is verified
    if (!phoneVerified) {
      alert('Please verify your phone number before placing the order.');
      return;
    }
    
    setLoading(true);

    try {
      // Generate order ID
      const orderId = `LAHORI-${Date.now().toString(36).toUpperCase()}`;
      
      const orderData = {
        id: orderId,
        order_details: {
          items: state.items,
          total: state.total + 100,
          payment_method: 'Cash on Delivery'
        },
        customer_name: customerInfo.name,
        customer_phone: customerInfo.phone,
        total_price: state.total + 100
      };

      console.log('Attempting to save order:', orderData);

      // Insert order into Supabase database
      const { data, error } = await supabase
        .from('orders')
        .insert([orderData])
        .select()
        .single();

      if (error) {
        console.error('Supabase error details:', error);
        console.error('Error code:', error.code);
        console.error('Error message:', error.message);
        console.error('Error details:', error.details);
        throw new Error(`Database error: ${error.message}`);
      }

      console.log('Order saved successfully:', data);

      // Send email notification using EmailJS from frontend
      await sendOrderEmail(orderId, {
        items: state.items,
        total: state.total + 100,
        customerInfo,
        paymentMethod: 'Cash on Delivery'
      });

             // WhatsApp order confirmation removed to avoid daily limits
             // Customers will receive email confirmation instead

             // WhatsApp owner notification removed to avoid daily limits
             // Owner will receive email notification instead
      
      // Clear cart
      dispatch({ type: 'CLEAR_CART' });
      // Navigate to confirmation page
      navigate(`/confirmation/${orderId}`);
      
    } catch (error) {
      console.error('Order submission error:', error);
      console.error('Error type:', typeof error);
      console.error('Error message:', error.message);
      console.error('Error stack:', error.stack);
      alert(`Failed to place order: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

         // WhatsApp owner notification removed to avoid daily limits
         // Owner will receive email notification instead

         // WhatsApp order confirmation removed to avoid daily limits
         // Customers will receive email confirmation instead

  // Send order emails using EmailJS (both to business and customer)
  const sendOrderEmail = async (orderId: string, orderData: any) => {
    try {
      console.log('📧 Starting email sending process...');
      console.log('📧 Order ID:', orderId);
      console.log('📧 Customer Info:', orderData.customerInfo);
      
      const items = orderData.items.map((item: any) => 
        `• ${item.name} x${item.quantity} - Rs.${item.price * item.quantity}`
      ).join('\n');

      console.log('📧 Order Items:', items);

      // Send email to business (you)
      console.log('📧 Sending business email...');
      const businessEmailResponse = await fetch('https://api.emailjs.com/api/v1.0/email/send', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
               body: JSON.stringify({
                 service_id: 'service_huwxfin',
                 template_id: 'template_5sle4gl', // Correct Template ID from your dashboard
                 user_id: 'aFnOBMy5siQAFBFJ1',
          template_params: {
            order_id: orderId,
            customer_name: orderData.customerInfo.name,
            customer_phone: orderData.customerInfo.phone,
            customer_email: orderData.customerInfo.email,
            customer_address: orderData.customerInfo.address,
            order_items: items,
            total_amount: orderData.total,
            order_date: new Date().toLocaleDateString('en-PK', { 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            }),
            delivery_time: '15-30 minutes',
            shop_phone: '+92 324 4060113',
            payment_method: 'Cash on Delivery',
            tracking_link: '#'
          }
        })
      });

      console.log('📧 Business email response status:', businessEmailResponse.status);
      console.log('📧 Business email response ok:', businessEmailResponse.ok);
      
      if (!businessEmailResponse.ok) {
        const errorText = await businessEmailResponse.text();
        console.error('❌ Business email failed:', errorText);
      } else {
        console.log('✅ Business email sent successfully');
      }

      // Send email to customer (if they provided email)
      let customerEmailResponse: Response | null = null;
      if (orderData.customerInfo.email) {
        console.log('📧 Sending customer email to:', orderData.customerInfo.email);
        customerEmailResponse = await fetch('https://api.emailjs.com/api/v1.0/email/send', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
               body: JSON.stringify({
                 service_id: 'service_huwxfin',
                 template_id: 'template_w6rt2f5', // Correct Template ID from your dashboard
                 user_id: 'aFnOBMy5siQAFBFJ1',
            template_params: {
              order_id: orderId,
              customer_name: orderData.customerInfo.name,
              customer_phone: orderData.customerInfo.phone,
              customer_email: orderData.customerInfo.email,
              customer_address: orderData.customerInfo.address,
              order_items: items,
              total_amount: orderData.total,
              order_date: new Date().toLocaleDateString('en-PK', { 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
              }),
              delivery_time: '15-30 minutes',
              shop_phone: '+92 324 4060113',
              payment_method: 'Cash on Delivery',
              tracking_link: '#',
              website_url: window.location.origin,
              to_email: orderData.customerInfo.email
            }
          })
        });
        
        console.log('📧 Customer email response status:', customerEmailResponse.status);
        console.log('📧 Customer email response ok:', customerEmailResponse.ok);
        
        if (!customerEmailResponse.ok) {
          const errorText = await customerEmailResponse.text();
          console.error('❌ Customer email failed:', errorText);
        } else {
          console.log('✅ Customer email sent successfully');
        }
      } else {
        console.log('⚠️ No customer email provided, skipping customer email');
      }

      // Final status report
      if (businessEmailResponse?.ok) {
        console.log('✅ Business order email sent successfully');
      } else {
        console.log('❌ Failed to send business order email');
        console.log('Business email response status:', businessEmailResponse?.status);
        if (businessEmailResponse) {
          const errorText = await businessEmailResponse.text();
          console.log('Business email response:', errorText);
        }
      }

      if (customerEmailResponse?.ok) {
        console.log('✅ Customer confirmation email sent successfully');
      } else if (orderData.customerInfo.email) {
        console.log('❌ Failed to send customer confirmation email');
        console.log('Customer email response status:', customerEmailResponse?.status);
        console.log('Customer email:', orderData.customerInfo.email);
        if (customerEmailResponse) {
          const errorText = await customerEmailResponse.text();
          console.log('Customer email response:', errorText);
        }
      }
    } catch (error) {
      console.error('❌ Error sending emails:', error);
      console.error('Error details:', error.message);
      console.error('Error stack:', error.stack);
    }
  };

  // Don't render the page if there are no items (will redirect via useEffect)
  if (state.items.length === 0) {
    return null;
  }

  return (
    <div className="pt-20 min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Page Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl lg:text-4xl text-gray-900 mb-2">Checkout</h1>
          <p className="text-gray-600">Complete your order details</p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Checkout Form */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="space-y-6"
          >
            {/* Customer Information */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-xl text-gray-900 mb-6 flex items-center">
                <User className="w-5 h-5 mr-2 text-orange-600" />
                Customer Information
              </h2>
              
              <form onSubmit={handleSubmitOrder} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm text-gray-700 mb-2">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      name="name"
                      required
                      value={customerInfo.name}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                      placeholder="Enter your full name"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm text-gray-700 mb-2">
                      Phone Number *
                    </label>
                    <div className="space-y-2">
                      <input
                        type="tel"
                        name="phone"
                        required
                        value={customerInfo.phone}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                        placeholder="+92 XXX XXXXXXX"
                        disabled={phoneVerified}
                      />
                      {!phoneVerified && (
                        <motion.button
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={handleVerifyPhone}
                          className="w-full px-4 py-3 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors flex items-center justify-center space-x-2"
                        >
                          <Shield className="w-4 h-4" />
                          <span>Verify Phone Number</span>
                        </motion.button>
                      )}
                    </div>
                  </div>
                </div>

                  <div>
                    <label className="block text-sm text-gray-700 mb-2">
                      Email Address <span className="text-orange-500">*</span>
                      <span className="text-xs text-gray-500 ml-1">(for order confirmation)</span>
                    </label>
                    <input
                      type="email"
                      name="email"
                      required
                      value={customerInfo.email}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                      placeholder="your@email.com"
                    />
                  </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">
                    Delivery Address *
                  </label>
                  <textarea
                    name="address"
                    required
                    value={customerInfo.address}
                    onChange={handleInputChange}
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                    placeholder="Enter your complete delivery address"
                  />
                </div>
              </form>
            </div>

            {/* Payment Method */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-xl text-gray-900 mb-6 flex items-center">
                <CreditCard className="w-5 h-5 mr-2 text-orange-600" />
                Payment Method
              </h2>
              
              <div className="p-4 border-2 border-orange-600 rounded-lg bg-orange-50">
                <div className="flex items-center">
                  <input
                    type="radio"
                    id="cod"
                    name="payment"
                    checked
                    readOnly
                    className="w-4 h-4 text-orange-600"
                  />
                  <label htmlFor="cod" className="ml-3 text-gray-900">
                    Cash on Delivery
                  </label>
                </div>
                <p className="mt-2 text-sm text-gray-600">
                  Pay when your order is delivered to your doorstep
                </p>
              </div>
            </div>

            {/* WhatsApp Notification */}
            <div className="bg-green-50 border border-green-200 rounded-xl p-4">
              <div className="flex items-start">
                <MessageCircle className="w-5 h-5 text-green-600 mt-0.5 mr-3" />
                <div>
                  <h3 className="text-sm text-green-800 mb-1">Email Confirmation</h3>
                  <p className="text-xs text-green-700">
                    Your order details will be sent via email for confirmation and coordination.
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Order Summary */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="space-y-6"
          >
            {/* Order Items */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-xl text-gray-900 mb-6">Order Summary</h2>
              
              <div className="space-y-4 mb-6">
                {state.items.map((item) => (
                  <div key={item.id} className="flex justify-between items-center py-2">
                    <div>
                      <h3 className="text-gray-900">{item.name}</h3>
                      <p className="text-sm text-gray-600">Qty: {item.quantity}</p>
                    </div>
                    <span className="text-orange-600">Rs.{item.price * item.quantity}</span>
                  </div>
                ))}
              </div>

              <div className="border-t pt-4 space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="text-gray-900">Rs.{state.total}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Delivery Fee</span>
                  <span className="text-gray-900">Rs.100</span>
                </div>
                <div className="flex justify-between text-lg pt-2 border-t">
                  <span className="text-gray-900">Total</span>
                  <span className="text-orange-600">Rs.{state.total + 100}</span>
                </div>
              </div>
            </div>

            {/* Beautiful Floating Verification Badge */}
            {phoneVerified && (
              <motion.div
                initial={{ opacity: 0, scale: 0.8, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                transition={{ delay: 0.5, type: "spring", stiffness: 200 }}
                className="relative"
              >
                <div className="absolute -top-4 -right-4 z-10">
                  <div className="bg-gradient-to-r from-emerald-500 to-green-500 text-white px-4 py-2 rounded-full shadow-lg flex items-center space-x-2 animate-pulse">
                    <div className="w-2 h-2 bg-white rounded-full animate-ping"></div>
                    <Shield className="w-4 h-4" />
                    <span className="text-sm font-medium">Verified</span>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Place Order Button */}
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleSubmitOrder}
              disabled={loading}
              className="w-full px-6 py-4 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors shadow-lg text-lg disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Placing Order...' : 'Place Order'}
            </motion.button>

            {/* Delivery Info */}
            <div className="bg-orange-50 rounded-xl p-4">
              <h3 className="text-sm text-orange-800 mb-2 flex items-center">
                <MapPin className="w-4 h-4 mr-2" />
                Delivery Information
              </h3>
              <ul className="text-xs text-orange-700 space-y-1">
                <li>• Standard delivery: 2-3 business days</li>
                <li>• Free delivery on orders over Rs.1000</li>
                <li>• We deliver within Lahore city limits</li>
                <li>• Email confirmation will be sent</li>
              </ul>
            </div>
          </motion.div>
        </div>
      </div>

      {/* OTP Verification Modal */}
      {showOTPVerification && (
        <OTPVerification
          phone={customerInfo.phone}
          onVerified={handlePhoneVerification}
          onCancel={handleOTPCancel}
        />
      )}
    </div>
  );
}
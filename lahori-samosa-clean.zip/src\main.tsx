
  import { createRoot } from "react-dom/client";
  import App from "./App.tsx";
  import "./index.css";
  import { imagePerformance } from "./utils/imageOptimization";

  // Initialize performance monitoring
  imagePerformance.monitorLCP();

  createRoot(document.getElementById("root")!).render(<App />);
  
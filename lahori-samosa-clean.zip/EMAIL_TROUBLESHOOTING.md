# 📧 Email Delivery Troubleshooting Guide

## 🚨 **Issue: Emails Not Being Received**

If emails are not being received by both customers and business, follow these steps:

## 🔍 **Step 1: Check Browser Console**

1. **Open your website** in browser
2. **Press F12** to open Developer Tools
3. **Go to Console tab**
4. **Place a test order** and watch for email logs
5. **Look for these messages:**
   - `📧 Starting email sending process...`
   - `📧 Sending business email...`
   - `📧 Sending customer email...`
   - `✅ Business email sent successfully` or `❌ Business email failed`
   - `✅ Customer email sent successfully` or `❌ Customer email failed`

## 🧪 **Step 2: Run EmailJS Test**

1. **Copy the contents** of `test-emailjs-debug.js`
2. **Open browser console** (F12)
3. **Paste and run** the test script
4. **Check results** for both business and customer templates

## ⚙️ **Step 3: Verify EmailJS Configuration**

### **Check EmailJS Dashboard:**
1. **Go to** [EmailJS Dashboard](https://dashboard.emailjs.com/)
2. **Verify Service ID:** `service_huwxfin`
3. **Verify User ID:** `aFnOBMy5siQAFBFJ1`
4. **Check Templates:**
   - `template_lahori_business` (for business emails)
   - `template_lahori_customer` (for customer emails)

### **Common Issues:**

#### **❌ Template ID Mismatch**
- **Problem:** Template IDs in code don't match EmailJS dashboard
- **Solution:** Update template IDs in `CheckoutPage.tsx` to match dashboard

#### **❌ Missing Template Variables**
- **Problem:** Template variables don't match between code and EmailJS
- **Solution:** Ensure all variables in templates match exactly

#### **❌ Service Not Configured**
- **Problem:** Email service not properly set up
- **Solution:** Check EmailJS service configuration

#### **❌ User ID Incorrect**
- **Problem:** User ID doesn't match EmailJS account
- **Solution:** Verify User ID in EmailJS dashboard

## 📋 **Step 4: Template Variables Checklist**

### **Business Template Variables:**
- `{{order_id}}`
- `{{customer_name}}`
- `{{customer_phone}}`
- `{{customer_email}}`
- `{{customer_address}}`
- `{{order_items}}`
- `{{total_amount}}`
- `{{order_date}}`
- `{{delivery_time}}`
- `{{shop_phone}}`
- `{{payment_method}}`
- `{{tracking_link}}`

### **Customer Template Variables:**
- `{{order_id}}`
- `{{customer_name}}`
- `{{customer_phone}}`
- `{{customer_email}}`
- `{{customer_address}}`
- `{{order_items}}`
- `{{total_amount}}`
- `{{order_date}}`
- `{{delivery_time}}`
- `{{shop_phone}}`
- `{{payment_method}}`
- `{{tracking_link}}`
- `{{website_url}}`
- `{{to_email}}`

## 🔧 **Step 5: Quick Fixes**

### **Fix 1: Update Template IDs**
If template IDs are wrong, update in `CheckoutPage.tsx`:

```javascript
// Business template
template_id: 'YOUR_ACTUAL_BUSINESS_TEMPLATE_ID',

// Customer template  
template_id: 'YOUR_ACTUAL_CUSTOMER_TEMPLATE_ID',
```

### **Fix 2: Check Service Configuration**
1. **EmailJS Dashboard** → **Email Services**
2. **Verify service** is active and configured
3. **Check email provider** settings (Gmail, Outlook, etc.)

### **Fix 3: Test with Simple Template**
Create a simple test template in EmailJS:
1. **Subject:** `Test Email`
2. **Content:** `Hello {{customer_name}}, your order {{order_id}} is confirmed.`
3. **Variables:** `{{customer_name}}`, `{{order_id}}`

## 📊 **Step 6: Debug Information**

### **Check Console Logs:**
Look for these specific error messages:

- `❌ Business email failed:` - Business template issue
- `❌ Customer email failed:` - Customer template issue  
- `❌ Network error:` - Connection issue
- `❌ Error sending emails:` - General error

### **Common Error Codes:**
- **400:** Bad Request (template variables mismatch)
- **401:** Unauthorized (User ID incorrect)
- **404:** Not Found (Template ID incorrect)
- **500:** Server Error (EmailJS service issue)

## 🎯 **Step 7: Test Order Process**

1. **Add items to cart**
2. **Go to checkout**
3. **Fill customer information**
4. **Verify phone number**
5. **Place order**
6. **Check console logs**
7. **Check email inboxes**

## 📞 **Step 8: Contact Support**

If issues persist:
1. **Check EmailJS status** at [status.emailjs.com](https://status.emailjs.com)
2. **Contact EmailJS support** with error logs
3. **Verify email provider** settings

## ✅ **Success Indicators**

You'll know it's working when you see:
- `✅ Business email sent successfully`
- `✅ Customer email sent successfully`
- Emails arrive in inboxes within 1-2 minutes
- No error messages in console

---

**Remember:** Email delivery can take 1-2 minutes. Check spam folders if emails don't arrive immediately.

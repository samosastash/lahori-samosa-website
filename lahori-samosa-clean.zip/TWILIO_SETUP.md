# Twilio WhatsApp Setup Guide

## Environment Variables Required

Create a `.env` file in your project root with the following variables:

```env
TWILIO_ACCOUNT_SID=your_twilio_account_sid
TWILIO_AUTH_TOKEN=your_twilio_auth_token
```

## Getting Your Twilio Credentials

1. Go to [Twilio Console](https://console.twilio.com/)
2. Sign up for a free account
3. Get your Account SID and Auth Token from the Dashboard
4. Add them to your `.env` file

## WhatsApp Sandbox Setup

1. Go to WhatsApp Sandbox in Twilio Console
2. Follow the instructions to connect your WhatsApp
3. Use the sandbox number: `+14155238886`

## Testing

Once configured, restart your server and test the OTP functionality.

# 🚀 Deployment Guide - Lahori Samosa Website

## 📋 Prerequisites

1. **GitHub Account** (for code hosting)
2. **Vercel Account** (for hosting)
3. **Twilio Account** (for WhatsApp OTP)
4. **Supabase Account** (for database)
5. **EmailJS Account** (for email notifications)

## 🔧 Environment Variables Setup

### Required Environment Variables:

```env
# Twilio Configuration
TWILIO_ACCOUNT_SID=your_twilio_account_sid
TWILIO_AUTH_TOKEN=your_twilio_auth_token

# Supabase Configuration  
SUPABASE_URL=your_supabase_url
SUPABASE_ANON_KEY=your_supabase_anon_key

# EmailJS Configuration
EMAILJS_SERVICE_ID=your_emailjs_service_id
EMAILJS_TEMPLATE_ID_CUSTOMER=your_customer_template_id
EMAILJS_TEMPLATE_ID_BUSINESS=your_business_template_id
EMAILJS_USER_ID=your_emailjs_user_id

# Server Configuration
NODE_ENV=production
PORT=3001
```

## 🌐 Deployment Steps

### Step 1: Push to GitHub (Manual)

Since GitHub is blocking automated pushes due to secret detection, you'll need to:

1. **Create a new repository** on GitHub
2. **Manually upload** the project files (excluding `.env` files)
3. **Or use GitHub Desktop** to push the code

### Step 2: Deploy to Vercel

1. **Go to [Vercel](https://vercel.com/)**
2. **Sign up/Login** with your GitHub account
3. **Click "New Project"**
4. **Import your GitHub repository**
5. **Configure build settings:**
   - Framework Preset: `Vite`
   - Build Command: `npm run build`
   - Output Directory: `build`
   - Install Command: `npm install`

### Step 3: Add Environment Variables

In Vercel Dashboard:
1. Go to **Project Settings** → **Environment Variables**
2. Add all the environment variables listed above
3. Make sure to set them for **Production**, **Preview**, and **Development**

### Step 4: Deploy

1. **Click "Deploy"**
2. **Wait for build to complete**
3. **Your site will be live!**

## 🔗 Live URLs

After deployment, you'll get:
- **Production URL**: `https://your-project-name.vercel.app`
- **Custom Domain**: (if configured)

## 📱 Features Included

✅ **Responsive Design** - Works on all devices
✅ **WhatsApp OTP** - Phone verification system  
✅ **Side Cart** - Smooth shopping experience
✅ **Email Notifications** - Professional templates
✅ **Image Optimization** - Fast loading
✅ **SEO Ready** - Search engine optimized

## 🛠️ Post-Deployment

1. **Test all functionality**
2. **Configure custom domain** (optional)
3. **Set up analytics** (optional)
4. **Monitor performance**

## 📞 Support

If you encounter any issues during deployment, check:
- Environment variables are correctly set
- All services (Twilio, Supabase, EmailJS) are properly configured
- Build logs for any errors

---

**Your Lahori Samosa website is now ready to serve customers! 🎉**
